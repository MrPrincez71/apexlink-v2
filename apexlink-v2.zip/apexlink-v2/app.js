(() => {
  const STORAGE_KEY = 'apexlink_demo_leads_v2';
  const PROVIDER_KEY = 'apexlink_demo_providers_v2';
  const $ = (selector) => document.querySelector(selector);
  const toast = $('#toast');
  const nav = $('#mainNav');
  const menuToggle = $('#menuToggle');
  $('#year').textContent = new Date().getFullYear();
  const dateInput = $('#preferredDate');
  if (dateInput) dateInput.min = new Date().toISOString().slice(0, 10);

  function read(key) { try { return JSON.parse(localStorage.getItem(key) || '[]'); } catch { return []; } }
  function write(key, item) { const list = read(key); list.push(item); localStorage.setItem(key, JSON.stringify(list)); return list.length; }
  function showToast(message) { toast.textContent = message; toast.classList.add('show'); window.setTimeout(() => toast.classList.remove('show'), 4200); }
  function showMessage(target, message) { target.textContent = message; target.classList.add('show'); }
  function formObject(form) { return Object.fromEntries(new FormData(form).entries()); }
  function makeId(prefix) { return prefix + '-' + Date.now().toString(36).toUpperCase() + '-' + Math.random().toString(36).slice(2, 6).toUpperCase(); }

  menuToggle.addEventListener('click', () => {
    const isOpen = nav.classList.toggle('open');
    menuToggle.setAttribute('aria-expanded', String(isOpen));
    menuToggle.textContent = isOpen ? '×' : '☰';
  });
  nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => { nav.classList.remove('open'); menuToggle.setAttribute('aria-expanded', 'false'); menuToggle.textContent = '☰'; }));

  document.querySelectorAll('[data-service]').forEach(card => card.addEventListener('click', () => {
    $('#serviceSelect').value = card.dataset.service;
    $('#quote').scrollIntoView({ behavior: 'smooth' });
    window.setTimeout(() => $('#serviceSelect').focus({ preventScroll: true }), 450);
  }));
  document.querySelectorAll('[data-prefill]').forEach(link => link.addEventListener('click', () => { $('#serviceSelect').value = link.dataset.prefill; }));

  $('#quoteForm').addEventListener('submit', event => {
    event.preventDefault();
    const form = event.currentTarget;
    if (!form.reportValidity()) return;
    const data = formObject(form);
    const record = { id: makeId('REQ'), type: 'quote', status: 'New inquiry', createdAt: new Date().toISOString(), ...data };
    const count = write(STORAGE_KEY, record);
    form.reset();
    showMessage($('#formMessage'), `Demo request ${record.id} saved in this browser (${count} quote request${count === 1 ? '' : 's'} stored here). This is not yet sent to ApexLink or stored online. Connect Supabase before using this form with real customers.`);
    showToast('Demo quote request saved on this device.');
  });

  $('#providerForm').addEventListener('submit', event => {
    event.preventDefault();
    const form = event.currentTarget;
    if (!form.reportValidity()) return;
    const data = formObject(form);
    const record = { id: makeId('PRO'), type: 'provider', status: 'New provider inquiry', createdAt: new Date().toISOString(), ...data };
    const count = write(PROVIDER_KEY, record);
    form.reset();
    showMessage($('#providerMessage'), `Demo provider inquiry ${record.id} saved in this browser (${count} inquiry${count === 1 ? '' : 'ies'} stored here). It is not yet sent or stored online.`);
    showToast('Demo provider inquiry saved on this device.');
  });
})();
