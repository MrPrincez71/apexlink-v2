-- ApexLink starter schema. Review before production.
-- Run in Supabase SQL Editor. RLS is enabled and no public SELECT policies are added.
-- For anonymous public form submissions, prefer a server-side Edge Function with validation,
-- rate limiting, spam protection and controlled inserts rather than broad anon INSERT policies.

create extension if not exists pgcrypto;

create table if not exists public.quote_requests (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  status text not null default 'new' check (status in ('new','contacted','quoted','approved','assigned','in_progress','completed','cancelled','closed')),
  customer_name text not null check (char_length(customer_name) between 2 and 120),
  email text not null check (char_length(email) <= 254),
  phone text check (phone is null or char_length(phone) <= 40),
  service text not null check (char_length(service) <= 100),
  zip_code text not null check (zip_code ~ '^[0-9]{5}(-[0-9]{4})?$'),
  space_size text,
  preferred_date date,
  frequency text,
  details text check (details is null or char_length(details) <= 3000),
  estimated_price_cents integer check (estimated_price_cents is null or estimated_price_cents >= 0),
  provider_cost_cents integer check (provider_cost_cents is null or provider_cost_cents >= 0),
  assigned_provider_id uuid,
  internal_notes text
);

create table if not exists public.provider_inquiries (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  status text not null default 'new' check (status in ('new','reviewing','approved','declined','inactive')),
  contact_name text not null check (char_length(contact_name) between 2 and 120),
  business_name text,
  email text not null check (char_length(email) <= 254),
  zip_code text not null check (zip_code ~ '^[0-9]{5}(-[0-9]{4})?$'),
  services text not null,
  experience_availability text check (experience_availability is null or char_length(experience_availability) <= 3000),
  insurance_verified boolean not null default false,
  agreement_signed boolean not null default false,
  internal_notes text
);

alter table public.quote_requests enable row level security;
alter table public.provider_inquiries enable row level security;

-- Deliberately no anon SELECT/INSERT policies. This is secure-by-default but forms will not
-- write directly from the public browser until a validated server-side endpoint is created.
-- After creating authenticated admin accounts, add policies based on a verified admin role.
