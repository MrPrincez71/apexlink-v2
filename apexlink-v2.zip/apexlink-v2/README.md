# ApexLink v2 — Cleaning Coordination Website

Responsive static website starter for a service-coordination business focused on house cleaning and move-out cleaning.

## Included
- `index.html` — marketing site, service cards, quote request, provider inquiry, FAQ
- `styles.css` — responsive desktop/mobile design
- `app.js` — mobile nav, service-card prefill, validation, local-demo form storage
- `admin.html` — local demo inbox with CSV export
- `supabase/schema.sql` — starter schema for online storage (review and secure before production)

## Important demo limitation
Forms currently store data in the browser's `localStorage`. This means submissions do **not** reach you, do not sync between devices, and are not secure. `admin.html` is not protected by login. Do not use it for real customer or provider data until Supabase (or another backend) is connected and authorization is configured.

## Deploy to your existing Vercel project using GitHub
1. Download and unzip the package.
2. In GitHub, create a new repository such as `apexlink-v2` (keep it separate from PHARAOH).
3. Upload the contents of this folder to the repository root. Make sure `index.html`, `styles.css`, `app.js`, `admin.html`, and the `supabase` folder are at the root.
4. In Vercel, choose **Add New → Project**, import the new repository, leave Framework Preset as **Other** and build/output settings at defaults for a static site, then deploy.
5. Open the deployment URL on desktop and mobile. Submit test forms and visit `/admin.html` in the same browser to see demo submissions.
6. To update the site later, commit changes to GitHub; Vercel automatically redeploys when the repository is connected.

## Before real customers
1. Create a Supabase project and run `supabase/schema.sql` in SQL Editor.
2. Add Supabase client code to submit forms to the database; use the project URL and public/anon key only in the browser, never a service-role key.
3. Enable Row Level Security (RLS) and add carefully scoped policies. Public quote submission should not allow public reading of other customers' records. Provider records must not be publicly readable. An Edge Function or another server-side endpoint with rate limiting and spam protection is preferable for anonymous inserts.
4. Create authenticated admin access and policies so only your owner account can read/update inquiries.
5. Add a real contact email/phone, privacy policy, terms, cancellation/refund terms, service area and business identity.
6. Confirm provider vetting, written agreements, insurance, and applicable California/local legal requirements before assigning jobs or collecting payments.
7. Add payment processing only after the quote, provider, refund and cancellation workflow is agreed and tested. Payment providers charge fees; never collect card details directly in this website.

## Test checklist
- Mobile menu opens/closes and nav links work.
- Each service card fills the quote form with its service.
- Required quote fields validate; quote request saves locally.
- Provider inquiry validates and saves locally.
- `/admin.html` displays local demo records and exports CSV.
- No form is represented as a confirmed booking or online submission in demo mode.
